public class SimpleArray2 {
    public static void main(String[] args) {
        int score[] = new int[] {90, 85, 55, 94, 77};
 
        for(int i = 0; i < score.length; i++) 
            System.out.printf("score[%d] = %d\n", i, score[i]); 
    }
}