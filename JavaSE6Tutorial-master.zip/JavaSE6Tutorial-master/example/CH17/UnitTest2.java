package onlyfun.caterpillar;

public @interface UnitTest2 {
     String value() default "noMethod";
}