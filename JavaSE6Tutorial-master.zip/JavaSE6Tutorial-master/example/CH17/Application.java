package onlyfun.caterpillar;

public class Application {
    @Process(
       current = Process.Current.ANALYSIS,
       tester = "Justin Lin",
       ok = true
    )
    public void doSomething() {
        // ....
    }
}