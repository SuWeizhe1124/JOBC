package onlyfun.caterpillar;

public class CustomClass2 {
    @Override
    public String toString() {
        return "customObject";
    }
}