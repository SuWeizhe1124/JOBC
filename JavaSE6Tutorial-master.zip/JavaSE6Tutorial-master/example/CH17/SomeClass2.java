package onlyfun.caterpillar;

import java.util.*;

public class SomeClass2 {
    @SuppressWarnings(value={"unchecked"})
    public void doSomething() {
        Map map = new HashMap();
        map.put("some", "thing");
    }
}