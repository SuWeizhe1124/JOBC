package onlyfun.caterpillar;

import java.util.*;

public class SomeClass {
    public void doSomething() {
        Map map = new HashMap();
        map.put("some", "thing");
    }
}