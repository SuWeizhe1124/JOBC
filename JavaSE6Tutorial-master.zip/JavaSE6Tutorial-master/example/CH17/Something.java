package onlyfun.caterpillar;

public class Something {
    @Deprecated public Something getSomething() {
        return new Something();
    }
}