package onlyfun.caterpillar;

public class SomeClass3 {
    @SomeAnnotation(
       value = "annotation value1",
       name = "annotation name1"
    )
    public void doSomething() {  
        // ....      
    }
}