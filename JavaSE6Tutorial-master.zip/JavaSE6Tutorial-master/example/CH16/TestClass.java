package onlyfun.caterpillar;

public class TestClass {
    static {
        System.out.println("類別被載入");
    }
}