package onlyfun.caterpillar;

public class TestClass2 {
    static {
        System.out.println("[執行靜態區塊]");
    }
}