package onlyfun.caterpillar;

public class TestField {
    public int testInt;
    public String testString;
    
    public String toString() {
        return testInt + ":" + testString;
    }
}