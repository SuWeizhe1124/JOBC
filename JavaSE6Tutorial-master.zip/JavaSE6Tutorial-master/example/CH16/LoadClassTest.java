package onlyfun.caterpillar;

public class LoadClassTest {
    public static void main(String[] args) {
        TestClass test = null;
        System.out.println("宣告TestClass參考名稱");
        test = new TestClass();
        System.out.println("生成TestClass實例");
    }
}