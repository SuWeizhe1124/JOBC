package onlyfun.caterpillar;

public class CurrentTime {
    public static void main(String[] args) {
        System.out.println("現在時間 " 
               + System.currentTimeMillis());
    }
}