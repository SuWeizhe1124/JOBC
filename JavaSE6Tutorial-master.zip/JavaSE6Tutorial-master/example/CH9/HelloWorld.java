import static java.lang.System.out;

public class HelloWorld {
    public static void main(String[] args) {
        out.println("Hello! World!");
    }
}