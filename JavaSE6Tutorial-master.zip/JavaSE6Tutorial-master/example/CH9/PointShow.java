public class PointShow { 
    public static void main(String[] args) { 
        PointDemo demo = new PointDemo(5); 
 
        demo.showPoints(); 
    } 
}