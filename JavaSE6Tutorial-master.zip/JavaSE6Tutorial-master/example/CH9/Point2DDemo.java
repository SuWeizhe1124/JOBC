public class Point2DDemo { 
    public static void main(String[] args) { 
        onlyfun.caterpillar.Point2D p1 = new 
            onlyfun.caterpillar.Point2D(10, 20);
 
        System.out.printf("p1: (x, y) = (%d, %d)%n",
            p1.getX(), p1.getY()); 
    } 
}