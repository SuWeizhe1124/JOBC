package onlyfun.caterpillar;

public class Arrays {
    public static void sort(int[] arr) {
        // ....
    }
}