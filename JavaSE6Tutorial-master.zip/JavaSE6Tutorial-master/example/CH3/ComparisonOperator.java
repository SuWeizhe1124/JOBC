public class ComparisonOperator {
    public static void main(String[] args) {
        System.out.println("10 >  5 結果 " + (10 > 5)); 
        System.out.println("10 >= 5 結果 " + (10 >= 5)); 
        System.out.println("10 <  5 結果 " + (10 < 5)); 
        System.out.println("10 <= 5 結果 " + (10 <= 5)); 
        System.out.println("10 == 5 結果 " + (10 == 5)); 
        System.out.println("10 != 5 結果 " + (10 != 5));
    }
}