public class ErrDemo { 
    public static void main(String[] args) { 
         System.out.println("使用out輸出訊息"); 
         System.err.println("使用err輸出訊息"); 
    } 
}