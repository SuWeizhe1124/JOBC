public class SecondJavaForC {
    public static void main(String[] args) {
        System.out.printf("%s！ 這是您的第一個Java程式！", 
                          "C語言Fan").println();
    }
}