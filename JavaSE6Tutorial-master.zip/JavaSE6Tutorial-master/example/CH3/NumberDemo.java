public class NumberDemo {
    public static void main(String[] args) {
        // 十進位 19 轉成二進位 10011
        System.out.println(Integer.toBinaryString(19));

        // 十進位 19 轉成十六進位 13
        System.out.println(Integer.toHexString(19));

        // 十進位 19 轉成八進位 23
        System.out.println(Integer.toOctalString(19));
    }
}