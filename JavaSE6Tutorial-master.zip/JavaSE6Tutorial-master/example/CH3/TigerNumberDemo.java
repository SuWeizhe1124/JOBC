public class TigerNumberDemo {
    public static void main(String[] args) {
        // 輸出 19 的十進位表示
        System.out.printf("%d%n", 19);

        // 輸出 19 的八進位表示
        System.out.printf("%o%n", 19);

        // 輸出 19 的十六進位表示
        System.out.printf("%x%n", 19); 
    }
}