public class ThirdJavaForC {
    public static void main(String[] args) {
        System.out.printf("%s！ 這是您的第 %d 個Java程式！\n", 
                          "C語言Fan", 3);
    }
}