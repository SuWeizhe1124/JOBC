public class HelloJavaForC {
    public static void main(String[] args) {
        System.out.printf("%s！ 這是您的第一個Java程式！\n", 
                          "C語言Fan");
    }
}