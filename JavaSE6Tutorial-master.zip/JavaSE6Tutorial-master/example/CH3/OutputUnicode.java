public class OutputUnicode {
    public static void main(String[] args) {
        System.out.println("\u0048\u0065\u006C\u006C\u006F");
    }
}