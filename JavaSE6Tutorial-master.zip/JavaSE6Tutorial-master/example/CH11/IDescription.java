public interface IDescription {
    public String getDescription();
}