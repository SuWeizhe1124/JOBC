public class CommandTool {
    public static final String ADMIN = "onlyfun.caterpillar.admin";
    public static final String DEVELOPER = "onlyfun.caterpillar.developer";

    public void someMethod() {
        // ....
    }
}