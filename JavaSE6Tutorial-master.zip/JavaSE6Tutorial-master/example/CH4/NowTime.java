import java.util.Date;

public class NowTime {
    public static void main(String[] args) {
        Date date = new Date();
        System.out.println(date.toString());
    }
}