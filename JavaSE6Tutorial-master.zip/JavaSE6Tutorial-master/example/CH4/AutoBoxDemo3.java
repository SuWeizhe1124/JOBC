public class AutoBoxDemo3 {
    public static void main(String[] args) {
        Integer i1 = 200;
        Integer i2 = 200;
 
        if (i1 == i2) 
            System.out.println("i1 == i2");
        else 
            System.out.println("i1 != i2");
    }
}