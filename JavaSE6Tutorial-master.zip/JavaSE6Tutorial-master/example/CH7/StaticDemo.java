public class StaticDemo {
    public static void sayHello() {
        System.out.println("哈囉！");
    }

    public static void main(String[] args) {
        sayHello();
    }
}