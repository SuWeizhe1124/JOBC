public class SomeClass {
    static {
        System.out.println("類別被載入");
    }
}