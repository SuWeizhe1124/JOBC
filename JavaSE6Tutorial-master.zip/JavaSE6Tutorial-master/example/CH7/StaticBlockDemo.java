public class StaticBlockDemo {
    public static void main(String[] args) {
        SomeClass c = new SomeClass();
    }
}